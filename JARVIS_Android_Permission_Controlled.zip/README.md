# J.A.R.V.I.S. Android

Native Android starter project with separate permission-controlled modules:
Gemini, voice, SMS, call logs, WhatsApp/Instagram notification analysis, and reminders.

Open in Android Studio, sync Gradle, then Build > Build APK(s).

SMS/call data is handled locally by this starter. WhatsApp/Instagram access is notification-based and requires the user to enable Android Notification Access. A production/public app should use a secure backend for AI credentials.
