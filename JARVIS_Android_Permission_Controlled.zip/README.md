# Jarvis — Stage 1 Prototype

This is the first stage of the build: **mic → transcribe → Claude → speak**.
No wake word and no device-control actions yet — those come next once this
loop is solid.

## What it does
1. Tap the mic button.
2. Speak; Android's built-in `SpeechRecognizer` transcribes it.
3. The transcript is sent to the Claude API (`ClaudeClient.kt`).
4. The reply is shown on screen and read aloud with Android's `TextToSpeech`.

## Setup
1. Open this folder in Android Studio (Giraffe or newer).
2. Let Gradle sync — it will pull OkHttp and Kotlin coroutines automatically.
3. Open `MainActivity.kt` and replace:
   ```kotlin
   private val apiKey = "YOUR_ANTHROPIC_API_KEY"
   ```
   with your real key from console.anthropic.com.
4. Run on a physical device or emulator with Google Play services (needed
   for speech recognition to work well — emulators without it may fail
   silently).
5. Grant the microphone permission when prompted.

## Important security note
The API key is hardcoded in the app for this prototype stage only. That's
fine while it's just running on your own phone via Android Studio. Before
you ever share the APK, publish it, or put it on a device you don't fully
control, move the Claude API call behind a small backend you own (even a
single serverless function) so the key never ships inside the app binary.

## Next steps (not built yet)
- **Wake word**: add Picovoice Porcupine so you don't need to tap a button.
- **Actions**: extend `ClaudeClient` so it returns structured JSON
  (e.g. `{"action": "send_sms", "to": "...", "message": "..."}`) that
  `MainActivity` parses and executes via Android Intents.
- **Device control**: for anything beyond basic Intents (reading screen
  content, tapping into other apps), you'll need an `AccessibilityService`
  or Tasker integration — that's a separate, meatier build.
- **Conversation memory**: currently every message is sent with no history.
  Add a running list of turns to `ClaudeClient.sendMessage` so it has
  context across a conversation.

## Known rough edges
- `SpeechRecognizer` here uses the one-shot dialog-free API; on some OEM
  skins (Samsung, Xiaomi) behavior varies. If it's unreliable, switching to
  a cloud STT (e.g. streaming via Whisper API) is more consistent but adds
  latency and cost.
- No retry/backoff on network failure — the error just prints to the status
  text.
