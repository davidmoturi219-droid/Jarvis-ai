package com.jarvis.assistant

import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Minimal client for the Anthropic Messages API.
 *
 * SECURITY NOTE: Never ship a real API key hardcoded in the app like this in
 * production — anyone can decompile the APK and steal it. For a personal
 * prototype running only on your own device this is fine to get started,
 * but before sharing the app or publishing it, move this call behind your
 * own small backend server that holds the key server-side.
 */
class ClaudeClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val endpoint = "https://api.anthropic.com/v1/messages"

    // A short system prompt that keeps responses voice-friendly and lets the
    // model signal structured actions (like "open an app") when relevant.
    private val systemPrompt = """
        You are Jarvis, a concise voice assistant running on the user's phone.
        Keep replies short and speakable (1-3 sentences) since they will be read
        aloud by text-to-speech. If the user asks you to do something on their
        phone (open an app, send a text, set an alarm), briefly confirm what
        you'd do — actual execution is handled by the app, not by you.
    """.trimIndent()

    fun sendMessage(userText: String, callback: (String?, Exception?) -> Unit) {
        val messages = JSONArray().put(
            JSONObject().put("role", "user").put("content", userText)
        )

        val body = JSONObject().apply {
            put("model", "claude-sonnet-4-6")
            put("max_tokens", 300)
            put("system", systemPrompt)
            put("messages", messages)
        }

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(RequestBody.create(
                MediaType.parse("application/json"), body.toString()
            ))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(null, e)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        callback(null, IOException("API error: ${it.code} ${it.body?.string()}"))
                        return
                    }
                    val json = JSONObject(it.body?.string() ?: "{}")
                    val content = json.optJSONArray("content")
                    val text = content?.optJSONObject(0)?.optString("text")
                    callback(text, null)
                }
            }
        })
    }
}
