package com.jarvis.mobile
import android.Manifest
import android.app.AlertDialog
import android.content.*;import android.content.pm.PackageManager;import android.net.Uri;import android.os.*
import android.provider.CallLog;import android.speech.*;import android.speech.tts.TextToSpeech
import android.widget.*;import androidx.activity.result.contract.ActivityResultContracts;import androidx.appcompat.app.AppCompatActivity;import androidx.core.content.ContextCompat
import kotlinx.coroutines.*;import org.json.*;import java.net.HttpURLConnection;import java.net.URL;import java.text.DateFormat;import java.util.*
class MainActivity:AppCompatActivity(),TextToSpeech.OnInitListener{
 lateinit var status:TextView;lateinit var console:TextView;lateinit var results:TextView;lateinit var api:EditText;lateinit var cmd:EditText;lateinit var tts:TextToSpeech;var sr:SpeechRecognizer?=null
 val p by lazy{getSharedPreferences("jarvis",0)}
 val req=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){status.text="ONLINE • READY"}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);status=findViewById(R.id.status);console=findViewById(R.id.console);results=findViewById(R.id.results);api=findViewById(R.id.apiKey);cmd=findViewById(R.id.command);api.setText(p.getString("key",""));tts=TextToSpeech(this,this);setup()}
 fun setup(){
  findViewById<Button>(R.id.saveKey).setOnClickListener{val k=api.text.toString().trim();if(k.isEmpty()){toast("Enter a Gemini key.");return@setOnClickListener};p.edit().putString("key",k).apply();reply("Gemini core connected, sir.")}
  findViewById<Button>(R.id.send).setOnClickListener{val s=cmd.text.toString().trim();if(s.isNotEmpty()){cmd.text.clear();ask(s)}}
  findViewById<Button>(R.id.speakButton).setOnClickListener{if(!has(Manifest.permission.RECORD_AUDIO))req.launch(arrayOf(Manifest.permission.RECORD_AUDIO))else listen()}
  findViewById<Switch>(R.id.smsModule).setOnCheckedChangeListener{_,on->if(on)req.launch(arrayOf(Manifest.permission.READ_SMS))}
  findViewById<Switch>(R.id.callModule).setOnCheckedChangeListener{_,on->if(on)req.launch(arrayOf(Manifest.permission.READ_CALL_LOG))}
  findViewById<Switch>(R.id.notificationModule).setOnCheckedChangeListener{_,on->if(on)startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))}
  findViewById<Switch>(R.id.reminderModule).setOnCheckedChangeListener{_,on->if(on&&Build.VERSION.SDK_INT>=33)req.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))}
  findViewById<Button>(R.id.readSms).setOnClickListener{sms()};findViewById<Button>(R.id.readCalls).setOnClickListener{calls()}
  findViewById<Button>(R.id.openNotificationSettings).setOnClickListener{startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))}
  findViewById<Button>(R.id.addReminder).setOnClickListener{reminder()}
 }
 fun has(x:String)=ContextCompat.checkSelfPermission(this,x)==PackageManager.PERMISSION_GRANTED
 fun listen(){if(!SpeechRecognizer.isRecognitionAvailable(this)){toast("Speech recognition unavailable.");return};sr?.destroy();sr=SpeechRecognizer.createSpeechRecognizer(this);sr!!.setRecognitionListener(object:RecognitionListener{
  override fun onReadyForSpeech(b:Bundle?){status.text="LISTENING..."};override fun onResults(b:Bundle?){val s=b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty();if(s.isNotBlank()){cmd.setText(s);ask(s)};status.text="ONLINE • READY"}
  override fun onError(e:Int){status.text="ONLINE • READY";toast("Voice input failed.")};override fun onBeginningOfSpeech(){};override fun onRmsChanged(v:Float){};override fun onBufferReceived(b:ByteArray?){};override fun onEndOfSpeech(){};override fun onPartialResults(b:Bundle?){};override fun onEvent(t:Int,b:Bundle?){}
 });sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.US);putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1)})}
 fun sms(){if(!has(Manifest.permission.READ_SMS)){req.launch(arrayOf(Manifest.permission.READ_SMS));return};val s=StringBuilder();contentResolver.query(Uri.parse("content://sms/inbox"),arrayOf("address","date","body"),null,null,"date DESC")?.use{c->var n=0;while(c.moveToNext()&&n<10){s.append("SMS • ").append(c.getString(0)).append(" • ").append(DateFormat.getDateTimeInstance().format(Date(c.getLong(1)))).append("\n").append(c.getString(2)).append("\n\n");n++}};results.text=s.toString().ifBlank{"No recent SMS found."};reply("Recent SMS are displayed locally, sir.")}
 fun calls(){if(!has(Manifest.permission.READ_CALL_LOG)){req.launch(arrayOf(Manifest.permission.READ_CALL_LOG));return};val s=StringBuilder();contentResolver.query(CallLog.Calls.CONTENT_URI,arrayOf(CallLog.Calls.NUMBER,CallLog.Calls.DATE,CallLog.Calls.TYPE,CallLog.Calls.DURATION),null,null,"date DESC")?.use{c->var n=0;while(c.moveToNext()&&n<10){val t=when(c.getInt(2)){1->"INCOMING";2->"OUTGOING";3->"MISSED";else->"OTHER"};s.append(t).append(" • ").append(c.getString(0)).append(" • ").append(DateFormat.getDateTimeInstance().format(Date(c.getLong(1)))).append(" • ").append(c.getString(3)).append(" sec\n");n++}};results.text=s.toString().ifBlank{"No recent calls found."};reply("Recent call activity is displayed locally, sir.")}
 fun reminder(){val e=EditText(this);e.hint="Reminder text";AlertDialog.Builder(this).setTitle("J.A.R.V.I.S. Reminder").setView(e).setMessage("Starter demo: fires about one minute from now.").setPositiveButton("SET"){_,_->ReminderScheduler.schedule(this,e.text.toString().ifBlank{"JARVIS reminder"},System.currentTimeMillis()+60000);reply("Reminder scheduled, sir.")}.setNegativeButton("CANCEL",null).show()}
 fun ask(s:String){val k=p.getString("key","").orEmpty();if(k.isBlank()){toast("Save your Gemini key first.");return};status.text="THINKING...";CoroutineScope(Dispatchers.IO).launch{val r=try{Gemini.ask(k,s)}catch(_:Exception){"I cannot reach Gemini right now, sir."};withContext(Dispatchers.Main){reply(r);status.text="ONLINE • READY"}}}
 override fun onInit(c:Int){if(c==TextToSpeech.SUCCESS){tts.language=Locale.US;tts.setSpeechRate(.95f);tts.setPitch(.82f)}};fun speak(s:String){tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis")};fun reply(s:String){console.text=s;speak(s)};fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show();override fun onDestroy(){sr?.destroy();tts.shutdown();super.onDestroy()}
}
object Gemini{
 fun ask(k:String,s:String):String{val c=URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent").openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("x-goog-api-key",k)
  val j=JSONObject().put("contents",JSONArray().put(JSONObject().put("parts",JSONArray().put(JSONObject().put("text","You are J.A.R.V.I.S., a concise helpful Android voice assistant. Address the user as sir occasionally. Never claim access to phone data unless supplied. User: $s"))))).put("generationConfig",JSONObject().put("maxOutputTokens",500));c.outputStream.use{it.write(j.toString().toByteArray())};if(c.responseCode !in 200..299)throw Exception("HTTP ${c.responseCode}");return JSONObject(c.inputStream.bufferedReader().use{it.readText()}).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")}
}
