package com.jarvis.mobile
import android.app.*;import android.content.*;import android.os.Build;import android.provider.Settings
object ReminderScheduler{
 fun schedule(c:Context,text:String,at:Long){
  val a=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
  val i=Intent(c,ReminderReceiver::class.java).putExtra("text",text)
  val p=PendingIntent.getBroadcast(c,(at%Int.MAX_VALUE).toInt(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  if(Build.VERSION.SDK_INT>=31&&!a.canScheduleExactAlarms()){c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply{data=android.net.Uri.parse("package:${c.packageName}")});return}
  a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p)
 }
}
