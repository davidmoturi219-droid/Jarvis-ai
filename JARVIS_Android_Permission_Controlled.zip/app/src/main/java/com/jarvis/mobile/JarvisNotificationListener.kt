package com.jarvis.mobile
import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentLinkedQueue
class JarvisNotificationListener: NotificationListenerService() {
 companion object { val recent=ConcurrentLinkedQueue<String>(); private val apps=setOf("com.whatsapp","com.instagram.android","com.google.android.apps.messaging","com.android.mms") }
 override fun onNotificationPosted(sbn:StatusBarNotification) {
  if(sbn.packageName !in apps)return
  val e=sbn.notification.extras
  val t=e.getString(Notification.EXTRA_TITLE).orEmpty()
  val x=e.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
  if(t.isBlank()&&x.isBlank())return
  recent.add("${sbn.packageName} | $t | $x")
  while(recent.size>50)recent.poll()
 }
}
