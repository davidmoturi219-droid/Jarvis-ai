package com.jarvis.mobile
import android.app.*;import android.content.*;import android.os.Build
import androidx.core.app.NotificationCompat
class ReminderReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){
  val text=i.getStringExtra("text")?:"J.A.R.V.I.S. reminder";val ch="jarvis_reminders"
  val nm=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(ch,"J.A.R.V.I.S. Reminders",NotificationManager.IMPORTANCE_HIGH))
  val pi=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  nm.notify((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),NotificationCompat.Builder(c,ch).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("J.A.R.V.I.S. Reminder").setContentText(text).setAutoCancel(true).setContentIntent(pi).build())
 }
}
